# StarPatterns
An attempt to implement Islamic Star Patterns.
* Paper: http://www.cgl.uwaterloo.ca/csk/papers/gi2005.html
* Paul Bourke line geometry: 
* Video: https://www.youtube.com/watch?v=sJ6pMLp_IaI
* View:  https://codingtrain.github.io/StarPatterns/
